﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Timers;

namespace tableRobot
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        Button[,] board;
        int x1, y1, x2, y2;
        private void Form1_Load(object sender, EventArgs e)
        {
            board = new Button[20, 20];
            StreamReader sr = new StreamReader(Application.StartupPath + @"\input.txt");
            string text = sr.ReadLine();
            string[] bits = text.Split(' ');
            x1 = int.Parse(bits[0]);
            y1 = int.Parse(bits[1]);
            x1--;
            y1--;
            text = sr.ReadLine();
            bits = text.Split(' ');
            x2 = int.Parse(bits[0]);
            y2 = int.Parse(bits[1]);
            x2--;
            y2--;
            for (int i = 0; i < 20; i++)
            {
                
                text = sr.ReadLine();
                bits = text.Split(' ');
                for (int j = 0; j < 20; j++)
                {
                    board[i, j] = new Button();
                    board[i, j].Location = new Point((j * 30) + 30, (i * 30) + 30);
                    board[i, j].BackColor = Color.White;
                    board[i, j].Height = 30;
                    board[i, j].Width = 30;
                    if (bits[j] == "1")
                    {
                        board[i, j].BackColor = Color.Gray;
                        board[i, j].Enabled = false;
                    }
                }
            }
            board[x1, y1].BackColor = Color.Red;
            board[x1, y1].Enabled = true;
            board[x2, y2].BackColor = Color.Blue;
            board[x2, y2].Enabled = true;
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    this.Controls.Add(board[i, j]);
                }
            }
            this.WindowState = FormWindowState.Maximized;
            this.MinimumSize = this.Size;
            this.MaximumSize = this.Size;
        }

        List <int []> bfsIndex;
        DateTime dt;

        bool checkValid(int a , int b)
        {
            if (a < 0)
                return false;
            if (a >= 20)
                return false;
            if (b < 0)
                return false;
            if (b >= 20)
                return false;
            return board[a, b].Enabled;
        }

        bool answerVisited;

        void updateEnables()
        {
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    if (board[i, j].BackColor != Color.Gray)
                        board[i, j].Enabled = true;
                }
            }
        }


        struct ucsObject
        {
            public int x;
            public int y;
            public int distance;
            public int heuristic;
        }

        List<ucsObject> ucsIndexes;
     

        private void button4_Click(object sender, EventArgs e)
        {
            dt = DateTime.Now;
            ucsIndexes = new List<ucsObject>();
            ucsObject tmp = new ucsObject();// =  { x1, y1 , 0 };
            tmp.x = x1;
            tmp.y = y1;
            tmp.distance = 0;
            board[x1, y1].Tag = -1;
            ucsIndexes.Add(tmp);
            AStar();
            ucsIndexes.Clear();
            updateEnables();
            int tag1 = Convert.ToInt16(board[x2, y2].Tag);
            while (tag1 != -1)
            {
                int xk = tag1 / 20;
                int yk = tag1 % 20;
                board[xk, yk].BackColor = Color.LightCyan;
                if (xk == x1 && yk == y1)
                    break;
                tag1 = Convert.ToInt16(board[xk, yk].Tag);
                this.Refresh();
            }
        }

        void AStar()
        {
            if (ucsIndexes[0].x == x2 && ucsIndexes[0].y == y2)
            {
                return;
            }
            Color x = board[ucsIndexes[0].x, ucsIndexes[0].y].BackColor;
            board[ucsIndexes[0].x, ucsIndexes[0].y].BackColor = Color.Green;
            this.Refresh();
            for (int i = -1; i <= 1; i++)
            {
                for (int j = -1; j <= 1; j++)
                {
                    if (checkValid((ucsIndexes[0].x + i), (ucsIndexes[0].y + j)) == true)
                    {
                        ucsObject tmp = new ucsObject();
                        tmp.x = ucsIndexes[0].x + i;
                        tmp.y = ucsIndexes[0].y + j;
                        tmp.distance = ucsIndexes[0].distance + 1;
                        tmp.heuristic = Math.Abs(tmp.x - x2) + Math.Abs(tmp.y - y2);
                        ucsIndexes.Add(tmp);
                        board[(ucsIndexes[0].x + i), (ucsIndexes[0].y + j)].Enabled = false;
                        board[(ucsIndexes[0].x + i), (ucsIndexes[0].y + j)].Tag = ucsIndexes[0].x * 20 + (ucsIndexes[0].y);
                    }
                }
            }
            board[(ucsIndexes[0].x), (ucsIndexes[0].y)].BackColor = x;
            board[(ucsIndexes[0].x), (ucsIndexes[0].y)].Enabled = false;
            ucsIndexes.RemoveAt(0);
            ucsIndexes = ucsIndexes.OrderBy(o => (o.distance + o.heuristic)).ToList();
            AStar();
        }
    }
}
